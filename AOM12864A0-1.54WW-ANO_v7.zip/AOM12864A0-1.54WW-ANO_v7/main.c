#include <stdio.h>
#include <SSD1305.h>
int64_t i,y;

void main()
{
    Board_init();
    er_oled_begin();

    clearDisplay();
    drawLine(0,20,128,20);
    drawLine(95,0,95,64);



    drawString(0,0,"ARLENTUS");
    drawString(0,10,"CONTROL");


    while(1)
    {
        for(i=0;i<1000000;i++)
        {
            drawNumber(97, 0, i);
            CPUdelay(1000000);

        }
    }


}
